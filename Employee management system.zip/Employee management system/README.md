# Employee Management System (Tkinter + MySQL)

## What it does

- Add Employee
- Remove Employee
- Promote Employee (increase salary)
- Display Employees (table)

## Prerequisites

- Python 3.x
- MySQL Server running locally
- `pip install -r requirements.txt`

## Quick Start

1. Edit `db.py` and set:
   - DB_USER, DB_PASS (your MySQL credentials)
2. Run the app:

## python main.py

The app will auto-create:

- database `employee_db`
- table `employees`

## Manual schema (optional)

Use `schema.sql` if you prefer to create DB manually.

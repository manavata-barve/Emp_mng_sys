import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from mysql.connector import Error
from db import init_db, connect_db

class EmployeeApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Employee Management System")
        self.geometry("820x520")
        self.minsize(820, 520)

        # Top banner
        title = tk.Label(self, text="Employee Management System",
                         font=("Segoe UI", 18, "bold"))
        title.pack(pady=10)

        # Status bar
        self.status_var = tk.StringVar(value="Initializing database…")
        status = tk.Label(self, textvariable=self.status_var, anchor="w",
                          relief="groove")
        status.pack(fill="x", side="bottom")

        # Form frame
        form = tk.Frame(self, padx=10, pady=10)
        form.pack(fill="x")

        tk.Label(form, text="Name").grid(row=0, column=0, sticky="w", padx=4, pady=4)
        tk.Label(form, text="Age").grid(row=0, column=2, sticky="w", padx=4, pady=4)
        tk.Label(form, text="Department").grid(row=1, column=0, sticky="w", padx=4, pady=4)
        tk.Label(form, text="Salary").grid(row=1, column=2, sticky="w", padx=4, pady=4)

        self.name_var = tk.StringVar()
        self.age_var = tk.StringVar()
        self.dept_var = tk.StringVar()
        self.salary_var = tk.StringVar()

        e1 = tk.Entry(form, textvariable=self.name_var, width=30)
        e2 = tk.Entry(form, textvariable=self.age_var, width=15)
        e3 = tk.Entry(form, textvariable=self.dept_var, width=30)
        e4 = tk.Entry(form, textvariable=self.salary_var, width=15)

        e1.grid(row=0, column=1, padx=4, pady=4, sticky="w")
        e2.grid(row=0, column=3, padx=4, pady=4, sticky="w")
        e3.grid(row=1, column=1, padx=4, pady=4, sticky="w")
        e4.grid(row=1, column=3, padx=4, pady=4, sticky="w")

        # Buttons frame
        btns = tk.Frame(self, pady=6)
        btns.pack(fill="x")

        tk.Button(btns, text="Add Employee", width=18, command=self.add_employee).pack(side="left", padx=5)
        tk.Button(btns, text="Remove Selected", width=18, command=self.remove_selected).pack(side="left", padx=5)
        tk.Button(btns, text="Promote (Increase Salary)", width=22, command=self.promote_selected).pack(side="left", padx=5)
        tk.Button(btns, text="Refresh / Display All", width=20, command=self.load_employees).pack(side="left", padx=5)

        # Treeview (table)
        table_frame = tk.Frame(self)
        table_frame.pack(fill="both", expand=True, padx=10, pady=10)

        columns = ("emp_id", "name", "age", "department", "salary")
        self.tree = ttk.Treeview(table_frame, columns=columns, show="headings", height=12)
        self.tree.heading("emp_id", text="ID")
        self.tree.heading("name", text="Name")
        self.tree.heading("age", text="Age")
        self.tree.heading("department", text="Department")
        self.tree.heading("salary", text="Salary")

        self.tree.column("emp_id", width=60, anchor="center")
        self.tree.column("name", width=220)
        self.tree.column("age", width=80, anchor="center")
        self.tree.column("department", width=160)
        self.tree.column("salary", width=120, anchor="e")

        vsb = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(table_frame, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=vsb.set, xscroll=hsb.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")

        table_frame.grid_rowconfigure(0, weight=1)
        table_frame.grid_columnconfigure(0, weight=1)

        # Initialize DB, then load data
        ok, msg = init_db()
        self.status_var.set(msg)
        if ok:
            try:
                self.load_employees()
            except Error as e:
                messagebox.showerror("MySQL Error", str(e))
        else:
            messagebox.showerror("Database Error", msg)

        # double-click row -> load into form (optional UX)
        self.tree.bind("<Double-1>", self.populate_form_from_selection)

    # ---------------- Core ops ----------------

    def load_employees(self):
        """Display Employees."""
        for r in self.tree.get_children():
            self.tree.delete(r)

        conn = connect_db()
        cur = conn.cursor()
        cur.execute("SELECT emp_id, name, age, department, salary FROM employees ORDER BY emp_id DESC")
        for row in cur.fetchall():
            self.tree.insert("", "end", values=row)
        cur.close()
        conn.close()
        self.status_var.set("Employees loaded.")

    def validate_form(self):
        name = self.name_var.get().strip()
        age = self.age_var.get().strip()
        dept = self.dept_var.get().strip()
        salary = self.salary_var.get().strip()

        if not name or not age or not dept or not salary:
            messagebox.showwarning("Validation", "All fields are required.")
            return None
        try:
            age_i = int(age)
            if age_i <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Validation", "Age must be a positive integer.")
            return None
        try:
            sal_f = float(salary)
            if sal_f < 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("Validation", "Salary must be a valid non-negative number.")
            return None

        return name, age_i, dept, round(float(salary), 2)

    def add_employee(self):
        """Add Employee."""
        vals = self.validate_form()
        if not vals:
            return
        name, age, dept, salary = vals
        try:
            conn = connect_db()
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO employees (name, age, department, salary) VALUES (%s, %s, %s, %s)",
                (name, age, dept, salary)
            )
            conn.commit()
            cur.close()
            conn.close()
            self.load_employees()
            self.status_var.set(f"Employee '{name}' added.")
            self.clear_form()
        except Error as e:
            messagebox.showerror("MySQL Error", str(e))

    def remove_selected(self):
        """Remove Employee (selected row)."""
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Select Row", "Please select an employee from the table.")
            return
        emp_id = self.tree.item(sel[0])["values"][0]
        if not messagebox.askyesno("Confirm Delete", f"Delete employee ID {emp_id}?"):
            return
        try:
            conn = connect_db()
            cur = conn.cursor()
            cur.execute("DELETE FROM employees WHERE emp_id=%s", (emp_id,))
            conn.commit()
            cur.close()
            conn.close()
            self.load_employees()
            self.status_var.set(f"Employee ID {emp_id} removed.")
        except Error as e:
            messagebox.showerror("MySQL Error", str(e))

    def promote_selected(self):
        """
        Promote Employee = increase salary by a given amount.
        (You can change to percentage if needed.)
        """
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Select Row", "Please select an employee from the table.")
            return
        emp_id, name = self.tree.item(sel[0])["values"][0], self.tree.item(sel[0])["values"][1]
        try:
            inc = simpledialog.askfloat("Promote", f"Increase salary for {name} (amount):", minvalue=0.0)
            if inc is None:
                return
            conn = connect_db()
            cur = conn.cursor()
            cur.execute("UPDATE employees SET salary = salary + %s WHERE emp_id = %s", (inc, emp_id))
            conn.commit()
            cur.close()
            conn.close()
            self.load_employees()
            self.status_var.set(f"Employee ID {emp_id} promoted (+{inc}).")
        except Error as e:
            messagebox.showerror("MySQL Error", str(e))

    # ---------------- helpers ----------------

    def populate_form_from_selection(self, _evt=None):
        sel = self.tree.selection()
        if not sel:
            return
        _, name, age, dept, salary = self.tree.item(sel[0])["values"]
        self.name_var.set(name)
        self.age_var.set(str(age))
        self.dept_var.set(dept)
        self.salary_var.set(str(salary))

    def clear_form(self):
        self.name_var.set("")
        self.age_var.set("")
        self.dept_var.set("")
        self.salary_var.set("")

if __name__ == "__main__":
    app = EmployeeApp()
    app.mainloop()

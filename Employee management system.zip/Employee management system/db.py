import mysql.connector
from mysql.connector import Error


DB_HOST = "localhost"
DB_USER = "root"
DB_PASS = ""         
DB_NAME = "employee_db"

def connect_server():
    """Connect to MySQL server (no database)."""
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASS
    )

def connect_db():
    """Connect directly to the project database."""
    return mysql.connector.connect(
        host=DB_HOST,
        user=DB_USER,
        password=DB_PASS,
        database=DB_NAME
    )

def init_db():
    """
    Creates database & employees table if they don't exist.
    Safe to call every time on app start.
    """
    try:
        # create database 
        conn = connect_server()
        cur = conn.cursor()
        cur.execute(f"CREATE DATABASE IF NOT EXISTS {DB_NAME}")
        conn.commit()
        cur.close()
        conn.close()

        # create table
        conn = connect_db()
        cur = conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS employees (
                emp_id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                age INT NOT NULL,
                department VARCHAR(50) NOT NULL,
                salary DECIMAL(10,2) NOT NULL
            )
        """)
        conn.commit()
        cur.close()
        conn.close()
        return True, "Database initialized."
    except Error as e:
        return False, f"MySQL error: {e}"
